package com.example.ljweapondatabase;

import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;

import java.util.List;

@Dao
public interface WeaponsDao {
    @Insert
    public void addWeaponToDatabase(Weapon weapon);

    @Insert
    public void addTypeToDatabase(Typ typ);

    @Delete
    public void deleteWeaponFromDatabase(Weapon weapon);

    @Update void updateWeaponInDatabase(Weapon weapon);

    @Query("SELECT * FROM Weapons")
    public List<Weapon> selectAllWeaponsInDatabase();
}
