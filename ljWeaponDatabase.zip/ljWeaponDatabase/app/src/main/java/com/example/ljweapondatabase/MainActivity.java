package com.example.ljweapondatabase;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.room.Room;
import androidx.room.RoomDatabase;
import androidx.sqlite.db.SupportSQLiteDatabase;

import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Toast;

import com.example.ljweapondatabase.databinding.ActivityMainBinding;

import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends AppCompatActivity {

    private ActivityMainBinding binding;
    private WeaponDatabase weaponDatabase;
    private ArrayAdapter<Character> arrayAdapter;
    private List<Character> character;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        binding = ActivityMainBinding.inflate(getLayoutInflater());
        View view = binding.getRoot();
        setContentView(view);

        RoomDatabase.Callback myCallBack = new RoomDatabase.Callback() {
            @Override
            public void onCreate(@NonNull SupportSQLiteDatabase db) {
                super.onCreate(db);
            }

            @Override
            public void onOpen(@NonNull SupportSQLiteDatabase db) {
                super.onOpen(db);
            }
        };
        weaponDatabase = Room.databaseBuilder(
                getApplicationContext(),
                WeaponDatabase.class,
                "weaponDatabase"
        ).addCallback(myCallBack).allowMainThreadQueries().build();

        binding.buttonAdd.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        //if(){
                        addWeaponToDatabase();
                        //}
                    }
                }
        );
    }
    private void addWeaponToDatabase(){
        ExecutorService executorService = Executors.newSingleThreadExecutor();
        Handler handler = new Handler(Looper.getMainLooper());
        executorService.execute(
                new Runnable() {
                    @Override
                    public void run() {

                        //Weapon weapon = new Weapon(binding.editTextName.getText().toString(), binding.editTextEffect.getText().toString(), Integer.parseInt(binding.editTextDate.getText().toString()), Integer.parseInt(binding.editTextType.getText().toString()));

                        //weaponDatabase.returnDao().addWeaponToDatabase(weapon);

                        weaponDatabase.returnDao().addTypeToDatabase(new Typ("Pistol"));
                        weaponDatabase.returnDao().addTypeToDatabase(new Typ("Gauntlets"));
                        weaponDatabase.returnDao().addTypeToDatabase(new Typ("Rectifier"));
                        weaponDatabase.returnDao().addTypeToDatabase(new Typ("Sword"));
                        weaponDatabase.returnDao().addTypeToDatabase(new Typ("Broadblade"));

                        handler.post(
                                new Runnable() {
                                    @Override
                                    public void run() {
                                        Toast.makeText(MainActivity.this, "Podziałało lepiej niż AK0", Toast.LENGTH_SHORT).show();
                                    }
                                }
                        );
                    }
                }
        );
    }
}