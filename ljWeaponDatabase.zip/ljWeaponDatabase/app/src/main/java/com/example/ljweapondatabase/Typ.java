package com.example.ljweapondatabase;

import android.media.metrics.Event;

import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity(tableName = "Typ")
public class Typ {
    @PrimaryKey(autoGenerate = true)
    private int id;
    private String typ;

    public Typ(String typ) {
        this.typ = typ;
    }

    public int getId() {
        return id;
    }

    public String getTyp() {
        return typ;
    }

    public void setId(int id) {
        this.id = id;
    }

    public void setTyp(String typ) {
        this.typ = typ;
    }
}
