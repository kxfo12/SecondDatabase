package com.example.ljweapondatabase;

import androidx.room.Dao;
import androidx.room.Database;
import androidx.room.RoomDatabase;

@Database(entities = {Weapon.class}, version = 1)
public abstract class WeaponDatabase extends RoomDatabase {
    public abstract WeaponsDao returnDao();
}
