package com.example.ljweapondatabase;

import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.ForeignKey;
import androidx.room.PrimaryKey;

@Entity(tableName = "Weapons", foreignKeys = @ForeignKey(
        entity = Typ.class,
        parentColumns = "id",
        childColumns = "id",
        onDelete = ForeignKey.CASCADE)
)
public class Weapon {
    @PrimaryKey(autoGenerate = true)
    private int id;
    private String name;
    private String effect;
    @ColumnInfo(name = "DateOfFirstConvene")
    private int date;
    private int type;

    public Weapon(String name, String effect, int date, int type) {
        this.name = name;
        this.effect = effect;
        this.date = date;
        this.type = type;
    }

    public int getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public String getEffect() {
        return effect;
    }

    public int getDate() {
        return date;
    }

    public int getType() {
        return type;
    }

    public void setId(int id) {
        this.id = id;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setEffect(String effect) {
        this.effect = effect;
    }

    public void setDate(int date) {
        this.date = date;
    }

    public void setType(int type) {
        this.type = type;
    }
}
